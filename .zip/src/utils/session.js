
import nextAppSession from 'next-app-session';

export const session = nextAppSession({
  name: 'DRPFXDNAKTHAFXPP',
  secret: 'zx0kfcvbfghjkqnmasdjvrtyuiop',
});